package edu.unibw.etti.racer;

public class Car extends Figure {

    public Car() {
        super(Configuration.CAR_FILE, Configuration.CAR_XPOS, Configuration.STREET_WIDTH_HALF);
    }

    public void reset() {
        set(Configuration.CAR_XPOS, Configuration.STREET_WIDTH_HALF);
    }
}
