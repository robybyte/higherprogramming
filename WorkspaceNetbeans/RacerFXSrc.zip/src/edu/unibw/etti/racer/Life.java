package edu.unibw.etti.racer;

public class Life extends Obstacle {
    public Life(double xPos, double yPos) {
        super(Configuration.LIFE_FILE, xPos, yPos, 0, 1, 0, 0);
    }
}
