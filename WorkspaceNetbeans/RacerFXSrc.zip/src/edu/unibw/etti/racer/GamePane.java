package edu.unibw.etti.racer;

import javafx.event.ActionEvent;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;

public class GamePane extends BorderPane {

    public GamePane(GameControl gameControl) {
        // TODO: Klasse MoveCarHandler schreiben!
        // TODO: Einbinden des MoveCarHandler!

        StreetPane streetPanel = new StreetPane(gameControl.score, gameControl.obstacles, gameControl.car);

        HBox bottom = new HBox(5);
        bottom.setAlignment(Pos.CENTER_LEFT);
        bottom.setPadding(new Insets(5));
        StartPauseButton startPauseBottom = new StartPauseButton();
        startPauseBottom.setPrefWidth(100);
        startPauseBottom.bindToGameControl(gameControl);
        startPauseBottom.addEventHandler(ActionEvent.ACTION, startPauseBottom);
        bottom.getChildren().add(startPauseBottom);
        
        // TODO: Klasse ScoreLabel schreiben!
        // TODO: Einbinden des ScoreLabel!

        setCenter(streetPanel);
        setBottom(bottom);
    }
}
