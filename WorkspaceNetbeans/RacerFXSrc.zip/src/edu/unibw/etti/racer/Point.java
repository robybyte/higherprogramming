package edu.unibw.etti.racer;

public class Point extends Obstacle {

    public Point(double xPos, double yPos) {
        super(Configuration.POINT_FILE, xPos, yPos, 5, 0, 0, 0);
    }
}
