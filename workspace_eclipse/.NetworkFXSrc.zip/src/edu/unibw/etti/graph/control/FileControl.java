package edu.unibw.etti.graph.control;

import edu.unibw.etti.graph.model.Edge;
import edu.unibw.etti.graph.model.Graph;
import edu.unibw.etti.graph.model.Vertex;
import java.io.File;
import java.util.HashMap;

/**
 * Lesen eines Graphen aus einer Datei und schreiben eines Graphen in eine
 * Datei.
 *
 * @author Sie
 */
public class FileControl {

    private final Graph graph;

    public FileControl(Graph graph) {
        this.graph = graph;
    }

    public void saveFile(File file) throws FileSaveException {
        System.out.println(file.getPath());

        // TODO Aufgabe c

    }

    public void openFile(File file) throws FileOpenException {
        System.out.println(file.getPath());

        // TODO Aufgabe f

        graph.update();
    }

}
