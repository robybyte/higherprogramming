// Aufgabe C
package edu.unibw.etti.graph.control;

import edu.unibw.etti.graph.model.Graph;
import edu.unibw.etti.graph.model.Vertex;

/**
 * Thread zum Bewegen eines Knotens auf dem Graphen.
 *
 * @author Sie
 */
public class TokenThread extends Thread {

    private final Graph graph;
    private final Vertex token;

    // TODO Aufgabe g, h, i 
    public TokenThread(Graph graph, Vertex token) {
        this.graph = graph;
        this.token = token;
    }

    @Override
    public void run() {
        // TODO Aufgabe g, h, i 
    }

}
